



echo "Stop master and slave server Apache Spark"

# Stop master and slave server Apache Spark 

$SPARK_HOME/sbin/stop-master.sh



