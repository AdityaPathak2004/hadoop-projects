import org.apache.spark.sql.Dataset;
import org.apache.spark.sql.Row;
import org.apache.spark.sql.SparkSession; // import Spark Session 


public class ShowDataframe
{
    public static void main(String[] args)

    {

//         SparkSession spark = SparkSession
//   .builder()
//   .appName("App name")
//   .config("spark.some.config.option", "some-value")
//   .getOrCreate();

// print - 
// mang phong cach kha la hay - con lau luon a - tai sao no lam duoc nhu vay 
  System.out.print("Works");
        // Inut spark 
// Dataset<Row> df = spark.read().json("./dataset/people.json");

// // Displays the content of the DataFrame to stdout

// df.show();

    }
}






// do a lot of joins - lol - cai day de thay me- e hay day 