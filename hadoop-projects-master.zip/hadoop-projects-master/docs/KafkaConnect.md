# Kafka connect using file Source and Sink

+ Start source connector and sink connector 