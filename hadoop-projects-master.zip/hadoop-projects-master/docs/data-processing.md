# Data pre processing 
+ Transform data in a different form 
+ Data type 


+ Data Cleaning 
    + Data scrubbing 
    + Delete corrupted data 
    + Data scaling
    + Data filtering 
    + Sort 
    + Merge 
    + Hashing 