## Run the program
+ Run the programm locally in the fs before run it on HDFS
+ Run the MR on Hadoop 
    + 


## Screenshots

<img src="./img/1.png">
<img src="./img/2.png">
<img src="./img/3.png">
+ Check with terminal 
<img src="./img/4.png">

