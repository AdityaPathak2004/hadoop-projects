#!/bin/bash
# Already install Zookeeper and Kafka 
brew services start zookeeper
brew services start kafka