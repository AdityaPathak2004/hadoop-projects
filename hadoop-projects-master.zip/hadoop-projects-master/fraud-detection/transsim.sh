#!/bin/bash
# Script to open 4 terminal window
while [ true ]
do 
echo 1 2 $RANDOM
sleep 1 
done 


# ko can run vao luc nay 